Latch client dependency notices
Original notice files from pinned dependencies and toolchains.
Go: executable dependencies across supported platforms.
Rust: full locked graph, including build/test and inactive-platform dependencies conservatively.
These third-party components retain their own licenses; Latch is MIT licensed.
